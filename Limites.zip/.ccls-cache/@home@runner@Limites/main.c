#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// CIC250 – Cálculo Numérico para Computação
// Exercicio Pratico 01 – 07/04/22
// 2019005687– Matheus Martins Batista
//
// Cálculo de raízes para funções reais – Limite sup, inf e passo

#define f(x) (x*x + 1.95*x - 2.09) //Altere as funções aqui

int main() {
    double lsup, linf, passo, prox = 0 ;
    int qtd = 0;

    printf("Limite inferior:");
    scanf(" %lf", &linf);
    printf("Limite superior:");
    scanf(" %lf", &lsup);
    printf("Passo:");
    scanf(" %lf", &passo);

    while(linf <= lsup){
        prox = linf + passo;
        if (f(linf)*f(prox) < 0){
            printf(" [%f, %f]", linf, linf + passo);
            qtd++;
        }
        linf += passo;
    }
    if (qtd == 0){
        printf("Não há raizes no intervalo fornecido!");
    }
    else{
        printf("\nPossui %d raizes", qtd);
    }
    return 0;
}
