#include <stdio.h>
#include <math.h>

// CIC250 – Cálculo Numérico para Computação
// Exercicio Pratico 01 – 07/04/22
// 2019005687– Matheus Martins Batista
//
// Cálculo de raízes para funções reais – Bissecção

#define f(x) (x*x + 1.95*x -2.09) //Altere as funções aqui
#define med(a,b) (a + b)/2 //Média aritmética

int main() {
    double a, b, E, M, x;
    int K = 1; //Quantidade de Iterações

    printf("Digite o intervalo:");
    scanf(" %lf %lf", &a, &b);
    printf("Digite a precisao E:");
    scanf(" %lf", &E);

    //Verificar se o intervalo fornecido não é inferior a precisão desejada
    if (fabs(b-a) < E){
        printf("Intervalo menor que a precisão exigida");
        return 0;
    }
    else{
        //while(fabs(b - a) > E){   //Roda enquando o valor absoluto de b - a é maior que a precisão,
        while(K < 10){         //pode-se limitar a quantidade de iterações por aqui
            M = f(a);
            x = med(a,b) ;
            if (M*f(x) > 0){
                a = x;
            }
            else{
                b = x;
            }
            K = K + 1;
        }
    }
    printf("Em %d de iteracoes no intervalo [%f, %f] a raiz aproximada obtida e: %lf", K,a, b, med(a,b));
    return 0;
}
