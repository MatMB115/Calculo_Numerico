#include <stdio.h>
#include <math.h>

// CIC250 – Cálculo Numérico para Computação
// Exercicio Pratico 01 – 07/04/22
// 2019005687– Matheus Martins Batista
//
// Cálculo de raízes para funções reais – Posição falsa

#define f(x) (x*x + 1.95*x - 2.09) //Altere as funções aqui
#define medP(a,b) (((a*f(b) - b*f(a))/(f(b) - f(a)))) //Calcula média ponderada

int main(){
    double a, b, E1, E2, x;
    int K; //Quantidade de iterações

    printf("Digite o intervalo:");
    scanf(" %lf %lf", &a, &b);
    printf("Digite a precisao E1:");
    scanf(" %lf", &E1);
    printf("Digite a precisao E2:");
    scanf(" %lf", &E2);

    if(fabs(b - a) < E1){
        if (fabs(a) < E2 || fabs(b) < E2){
            printf("X barra considerado raiz: %lf", a);
        }
    }
    K = 1;
    x = medP(a,b);
    while(fabs(b - a) > E1 && fabs(f(x)) > E2){
        if(f(a)*f(b) > 0){
            a = x;
        }
        else{
            b = x;
        }
        x = medP(a,b);
        K++;
    }
    printf("Em %d de iteracoes no intervalo [%f, %f] a raiz aproximada obtida e: %lf", K,a, b, x);

    return 0;
}
